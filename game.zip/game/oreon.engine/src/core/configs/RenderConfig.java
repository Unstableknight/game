package core.configs;

public interface RenderConfig {

	public void enable();
	
	public void disable();
}
