package core.buffers;

import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;

import core.model.Mesh;

public class MeshVBO implements VBO{
	
	private int vbId;
	private int ibId;
	private int vaoId;
	private int size;
	
    public MeshVBO() {
    	
    	vbId = GL15.glGenBuffers();
    	ibId = GL15.glGenBuffers();
    	vaoId = GL30.glGenVertexArrays();
    }

	@Override
	public void allocate(Mesh mesh) {
		
		size = mesh.getIndices().length;		
		
		GL30.glBindVertexArray(vaoId);
		
		GL15.glBindBuffer(GL15, arg1);
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

}
