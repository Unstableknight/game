# Lwjgl3-Game-Engine-StartingCode
## This is the Project Starting Code Template for the Lwjgl 3 Game Engine Programming Series

### Template implements:
* GLFW Window
* GLFW Input-Handler
* Game Loop
* Camera
* 3D Math (Matrices,Vectors)
* Shader Program Template
* OBJ-File Loader
* GLSL-File Loader